package com.apkb.reportapps.utils;


public class Constant {

    public static String lokasiPengaduan;

}
